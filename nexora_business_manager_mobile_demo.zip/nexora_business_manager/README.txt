# Nexora Business Manager — Mobile Responsive Demo

A lightweight browser-based portfolio demo built with separate HTML, CSS and JavaScript files.

## Files
- `index.html` — page structure
- `style.css` — responsive dashboard design
- `app.js` — demo data, transaction form, calculations, filtering, CSV export, and browser storage

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox).
3. Click **Add transaction** to record income or an expense.
4. Change the period, search/filter records, open the sidebar menu on mobile, or export a CSV.

No installation, build step, server, or internet connection is needed for the demo itself.

## Demo behaviour and limitations
- Initial sample transactions are included so the dashboard looks populated.
- New records are saved in this browser's `localStorage` on this device.
- This is NOT a secure multi-user production app. Data is not uploaded to a server and does not sync between devices.
- Clearing browser data may remove saved records. Export CSV backups when testing.
- CSV export follows the current period/search/type filters.
- All values are shown in PKR and amounts are rounded to whole rupees.

## Suggested next production stage
For real clients, add authenticated PHP backend endpoints and a MySQL database, server-side validation, access control, secure sessions, backups, and deployment to compatible PHP hosting. Do not put confidential customer/financial data into this front-end demo.
